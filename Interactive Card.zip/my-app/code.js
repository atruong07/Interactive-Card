var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["94adf84b-6dca-48d3-8c79-45f072c25a24","4420a89c-4b34-4676-aec1-3655412b1450","5be9c90c-6f8b-4cc2-be8e-1198ad51eb5e","e36895c3-ff74-446e-b722-a4e39ec0c719","4da9e9b8-717e-4302-9855-7b4a0b568bf1","1d971bba-26cf-43d8-b14a-d7f0e9d34f04","75bd6d8b-0c56-430b-84e0-ca7894ca5a43"],"propsByKey":{"94adf84b-6dca-48d3-8c79-45f072c25a24":{"name":"stage","sourceUrl":"assets/v3/animations/5Bs2n54RxbQwQ295LFA9ughUE4TN3GqOvOp0RfbzFK4/94adf84b-6dca-48d3-8c79-45f072c25a24.png","frameSize":{"x":960,"y":720},"frameCount":1,"looping":true,"frameDelay":4,"version":"v0hsdVBIfIuaOCHv96r9T.zOTMWULTFW","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":960,"y":720},"rootRelativePath":"assets/v3/animations/5Bs2n54RxbQwQ295LFA9ughUE4TN3GqOvOp0RfbzFK4/94adf84b-6dca-48d3-8c79-45f072c25a24.png"},"4420a89c-4b34-4676-aec1-3655412b1450":{"name":"rocker","sourceUrl":"assets/api/v1/animation-library/gamelab/bO3KvTIGBpz2yQ4A_psLtdJiX5YeAwGs/category_people/blue_shirt_hand_up2.png","frameSize":{"x":175,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"bO3KvTIGBpz2yQ4A_psLtdJiX5YeAwGs","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":175,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/bO3KvTIGBpz2yQ4A_psLtdJiX5YeAwGs/category_people/blue_shirt_hand_up2.png"},"5be9c90c-6f8b-4cc2-be8e-1198ad51eb5e":{"name":"guitar","sourceUrl":"assets/api/v1/animation-library/gamelab/ce03S5pRNytnGm4DWGxMZPmnXf3hFUTG/category_music/electric_guitar.png","frameSize":{"x":96,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"ce03S5pRNytnGm4DWGxMZPmnXf3hFUTG","categories":["music"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ce03S5pRNytnGm4DWGxMZPmnXf3hFUTG/category_music/electric_guitar.png"},"e36895c3-ff74-446e-b722-a4e39ec0c719":{"name":"music","sourceUrl":"assets/api/v1/animation-library/gamelab/dxUglVBNWsHzKRz9KLROyJrdXT3UgnBu/category_music/eighth_note_down.png","frameSize":{"x":212,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"dxUglVBNWsHzKRz9KLROyJrdXT3UgnBu","categories":["music"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":212,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dxUglVBNWsHzKRz9KLROyJrdXT3UgnBu/category_music/eighth_note_down.png"},"4da9e9b8-717e-4302-9855-7b4a0b568bf1":{"name":"note","sourceUrl":"assets/api/v1/animation-library/gamelab/BeMwQ8jrF6mwtB1P7j2TVQu_BSF0nt6E/category_music/eighth_note.png","frameSize":{"x":212,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"BeMwQ8jrF6mwtB1P7j2TVQu_BSF0nt6E","categories":["music"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":212,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/BeMwQ8jrF6mwtB1P7j2TVQu_BSF0nt6E/category_music/eighth_note.png"},"1d971bba-26cf-43d8-b14a-d7f0e9d34f04":{"name":"light1","sourceUrl":null,"frameSize":{"x":266,"y":381},"frameCount":1,"looping":true,"frameDelay":12,"version":"7pCG1I6EN7KeGNVJ42OMtDDYVhbe3Ndu","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":266,"y":381},"rootRelativePath":"assets/1d971bba-26cf-43d8-b14a-d7f0e9d34f04.png"},"75bd6d8b-0c56-430b-84e0-ca7894ca5a43":{"name":"light2","sourceUrl":null,"frameSize":{"x":266,"y":381},"frameCount":1,"looping":true,"frameDelay":12,"version":".srXrL.wCGAQP.kxOnNw0IRGZSRqcHut","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":266,"y":381},"rootRelativePath":"assets/75bd6d8b-0c56-430b-84e0-ca7894ca5a43.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var clicks = 0; 
function draw() {
  World.frameRate = 7;
  var stage = createSprite(200,200);
  stage.setAnimation("stage");
  background ("white"); 
  var rocker = createSprite(200,200);
  rocker.setAnimation ("rocker"); 
  rocker.scale = 0.5; 
  var note = createSprite(randomNumber(100,200), randomNumber(200,250));
  note.setAnimation("music"); 
  note.scale = 0.2; 
  var note2 = createSprite(randomNumber(200,300), randomNumber(200,250));
  note2.setAnimation("note"); 
  note2.scale = 0.2;   
  var guitar = createSprite(230,180);
  guitar.setAnimation ("guitar"); 
  guitar.scale = 0.5; 
  guitar.rotation = (randomNumber(30,40));
  var light1 = createSprite(350,150);
  light1.setAnimation("light1"); 
  light1.scale = 0.2; 
  var light2 = createSprite(40,150);
  light2.setAnimation("light2");
  light2.scale = 0.2; 
  if (keyDown("RIGHT_ARROW")){
    rocker.x = rocker.x + 15; 
  }
  if (keyDown("LEFT_ARROW")){
    rocker.x = rocker.x - 15; 
  }
  if (keyDown("space")){
    clicks = clicks + 1;
    note.visible = true; 
    note2.visible = true; 
  } else{
    note.visible = false; 
    note2.visible = false; 
  }
  if (clicks > 2) {
    light2.setAnimation("light1");
    light1.setAnimation("light2"); 
  }
  drawSprites(); 
  
fill("white");
textSize(15);
text("Hold Space Key For Music Notes To Appear and Lights!", 5, 40);
text("Move Arrow Keys to Move the Guitarist!", 50, 70);
text("Come See Us in Concert!", 100, 350);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
